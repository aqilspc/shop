<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//web
Route::get('/', function () {
	return view('index'); 
})->name('welcome');

Route::get('/404', function () {
	return view('404'); }
)->name('404');

Route::get('/about', function () {
	return view('about');
	 })->name('about');

Route::get('/address', function () {
	return view('address'); 
})->name('address');

Route::get('/alerts', function () {
	return view('alerts'); 
})->name('alerts');

Route::get('/blog', function () {
	return view('blog-full-width'); 
})->name('blog-full-width');

Route::get('/blog-grid', function () {
	return view('blog-grid'); 
})->name('blog-grid');

Route::get('/blog-left-sidebar', function () {
	return view('blog-left-sidebar'); 
})->name('blog-left-sidebar');

Route::get('/blog-right-sidebar', function () {
	return view('blog-right-sidebar'); 

})->name('blog-right-sidebar');
Route::get('/blog-single', function () {
	return view('blog-single'); 
})->name('blog-single');

Route::get('/buttons', function () {
	return view('buttons'); 
})->name('buttons');

Route::get('/cart', function () {
	return view('cart'); 
})->name('cart');

Route::get('/checkout', function () {
	return view('checkout'); 
})->name('checkout');

Route::get('/coming-soon', function () {
	return view('coming-soon');
	 })->name('coming-soon');

Route::get('/confirmation', function () {
	return view('confirmation'); 
})->name('confirmation');

Route::get('/contact', function () {
	return view('contact'); 
})->name('contact');

Route::get('/dashboard', function () {
	return view('dashboard');
	 })->name('dashboard');

Route::get('/empty-cart', function () {
	return view('empty-cart'); 
})->name('empty-cart');

Route::get('/faq', function () {
	return view('faq'); 
})->name('faq');

Route::get('/forget-password', function () {
	return view('forget-password');
	 })->name('forget-password');

Route::get('/home', function () {
	return view('home'); 
})->name('home');

Route::get('/loginweb', function () {
	return view('login');
	 })->name('login');

Route::get('/order', function () {
	return view('order'); 
})->name('order');

Route::get('/pricing', function () {
	return view('pricing');
	 })->name('pricing');

Route::get('/product-single', function () {
	return view('product-single'); 
})->name('product-single');

Route::get('/profile-details', function () {
	return view('profile-details');
	 })->name('profile-details');

Route::get('/purchase-confirmation', function () {
	return view('purchase-confirmation'); 
})->name('purchase-confirmation');

Route::get('/shop-sidebar', function () {
	return view('shop-sidebar');
	 })->name('shop-sidebar');

Route::get('/shop', function () {
	return view('shop'); 
})->name('shop');

Route::get('/signin', function () {
	return view('signin'); 
})->name('signin');

Route::get('/typography', function () {
	return view('typography');
	 })->name('typography');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/category', [App\Http\Controllers\HomeController::class, 'indexCategory']);
Route::get('/category_delete/{id}', [App\Http\Controllers\HomeController::class, 'deleteCategory']);
Route::get('/category_edit/{id}', [App\Http\Controllers\HomeController::class, 'indexCategoryEdit']);
Route::post('update_homes',[App\Http\Controllers\HomeController::class, 'updateHome']);
Route::post('category_create',[App\Http\Controllers\HomeController::class, 'createCategory']);
Route::post('category_update/{id}',[App\Http\Controllers\HomeController::class, 'updateCategory']);
