<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="page-header">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="content">
					<h1 class="page-name">Pricing Table</h1>
					<ol class="breadcrumb">
						<li><a href="index.blade.php">Home</a></li>
						<li class="active">pricing</li>
					</ol>
				</div>
			</div>
		</div>
	</div>
</section>

	<section class="pricing-table">
		<div class="container">
			<div class="row">
				<!-- single pricing table -->
				<div class="col-md-4 col-sm-6 col-xs-12" >
					<div class="pricing-item">
						
						<!-- plan name & value -->
						<div class="price-title">
							<h3>Basic</h3>
							<strong class="value">$99</strong>
							<p>Perfect for single freelancers who work by themselves</p>
						</div>
						<!-- /plan name & value -->
						
						<!-- plan description -->
						<ul>
							<li><i class="tf-ios-arrow-forward"></i> 1GB Disk Space</li>
							<li><i class="tf-ios-arrow-forward"></i> 10 Email Account</li>
							<li><i class="tf-ios-arrow-forward"></i> Script Installer</li>
							<li><i class="tf-ios-arrow-forward"></i> 1 GB Storage</li>
							<li><i class="tf-ios-arrow-forward"></i> 10 GB Bandwidth</li>
							<li><i class="tf-ios-arrow-forward"></i> 24/7 Tech Support</li>
						</ul>
						<!-- /plan description -->
						
						<!-- signup button -->
						<a class="btn btn-main" href="signin.blade.php">Signup</a>
						<!-- /signup button -->
						
					</div>
				</div>
				<!-- end single pricing table -->
				
				<!-- single pricing table -->
				<div class="col-md-4 col-sm-6 col-xs-12  "  >
					<div class="pricing-item">
					
						<!-- plan name & value -->
						<div class="price-title">
							<h3>Basic</h3>
							<strong class="value">$99</strong>
							<p>Suitable for small businesses with up to 5 employees</p>
						</div>
						<!-- /plan name & value -->
						
						<!-- plan description -->
						<ul>
							<li><i class="tf-ios-arrow-forward"></i> 1GB Disk Space</li>
							<li><i class="tf-ios-arrow-forward"></i> 10 Email Account</li>
							<li><i class="tf-ios-arrow-forward"></i> Script Installer</li>
							<li><i class="tf-ios-arrow-forward"></i> 1 GB Storage</li>
							<li><i class="tf-ios-arrow-forward"></i> 10 GB Bandwidth</li>
							<li><i class="tf-ios-arrow-forward"></i> 24/7 Tech Support</li>
						</ul>
						<!-- /plan description -->
						
						<!-- signup button -->
						<a class="btn btn-main" href="signin.blade.php">Signup</a>
						<!-- /signup button -->
						
					</div>
				</div>
				<!-- end single pricing table -->
				
				<!-- single pricing table -->
				<div class="col-md-4 col-sm-6 col-xs-12 ">
					<div class="pricing-item">
						
						<!-- plan name & value -->
						<div class="price-title">
							<h3>Basic</h3>
							<strong class="value">$99</strong>
							<p>Great for large businesses with more than 5 employees</p>
						</div>
						<!-- /plan name & value -->
						
						<!-- plan description -->
						<ul>
							<li><i class="tf-ios-arrow-forward"></i> 1GB Disk Space</li>
							<li><i class="tf-ios-arrow-forward"></i> 10 Email Account</li>
							<li><i class="tf-ios-arrow-forward"></i> Script Installer</li>
							<li><i class="tf-ios-arrow-forward"></i> 1 GB Storage</li>
							<li><i class="tf-ios-arrow-forward"></i> 10 GB Bandwidth</li>
							<li><i class="tf-ios-arrow-forward"></i> 24/7 Tech Support</li>
						</ul>
						<!-- /plan description -->
						
						<!-- signup button -->
						<a class="btn btn-main" href="signin.blade.php">Signup</a>
						<!-- /signup button -->
						
					</div>
				</div>
				<!-- end single pricing table -->
				
				
			</div>       <!-- End row -->
		</div>   	<!-- End container -->
	</section>   <!-- End section -->
	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kerja\php\htdocs\pwl\joki\kel6\resources\views/pricing.blade.php ENDPATH**/ ?>