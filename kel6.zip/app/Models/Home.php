<?php

namespace App\Models;

use DB;

class Home
{
    public function getHome()
    {
         $data = DB::table('homes')->where('id',1)->first();
         return $data;
    }
}
