<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        if(Auth::user()->role == 'admin')
        {
            $data = DB::table('homes')->where('id',1)->first();
            return view('admin',compact('data'));
        }else
        {
            return redirect('/');
        }
    }

    public function uploadFile(Request $request,$oke)
    {
            $result ='';
            $file = $request->file($oke);
            $name = $file->getClientOriginalName();
            // $tmp_name = $file['tmp_name'];

            $extension = explode('.',$name);
            $extension = strtolower(end($extension));

            $key = rand().'-'.$oke;
            $tmp_file_name = "{$key}.{$extension}";
            $tmp_file_path = "admin/images/";
            $file->move($tmp_file_path,$tmp_file_name);
            // if(move_uploaded_file($tmp_name, $tmp_file_path)){
            $result =url('admin/images').'/'.$tmp_file_name;
            // }
        return $result;
    }

    public function updateHome(Request $request)
    {
        $file1 = $request->file('slider1');
        $file2 = $request->file('slider2');
        $file3 = $request->file('slider3');
        $slider1 ='';
        $slider2 ='';
        $slider3 ='';
        if($file1!=null)
        {
            $slider1 = $this->uploadFile($request,'slider1');
        }else
        {
            $slider1 = $request->old_slider1;
        }

         if($file2!=null)
        {
            $slider2 = $this->uploadFile($request,'slider2');
        }else
        {
            $slider2 = $request->old_slider2;
        }

         if($file3!=null)
        {
            $slider3 = $this->uploadFile($request,'slider3');
        }else
        {
            $slider3 = $request->old_slider3;
        }
        DB::table('homes')->where('id',1)->update(
            [
                'name_shop'=>$request->name_shop
                ,'phone'=>$request->phone
                ,'text_slider1'=>$request->text_slider1
                ,'text_slider2'=>$request->text_slider2
                ,'text_slider3'=>$request->text_slider3
                ,'slider1'=>$slider1
                ,'slider2'=>$slider2
                ,'slider3'=>$slider3
            ]
        );

        return redirect()->back();
    }

    public function indexCategory()
    {
        $data = DB::table('categories')->get();
        return view('admin_category',compact('data'));
    }

    public function indexCategoryEdit($id)
    {
        $data = DB::table('categories')->where('id',$id)->first();
        return view('admin_category_update',compact('data'));
    }

    public function createCategory(Request $request)
    {
        $file1 = $request->file('foto');
        if($file1!=null)
        {
            $foto = $this->uploadFile($request,'foto');
        }else
        {
            $foto = $request->old_foto;
        }
        DB::table('categories')->insert(
            [
                'category_name'=>$request->category_name
                ,'slug'=>$request->slug
                ,'foto'=>$foto
            ]
        );
         return redirect()->back();
    }

    public function updateCategory(Request $request,$id)
    {
        $file1 = $request->file('foto');
        if($file1!=null)
        {
            $foto = $this->uploadFile($request,'foto');
        }else
        {
            $foto = $request->old_foto;
        }
        DB::table('categories')->where('id',$id)->update(
            [
                'category_name'=>$request->category_name
                ,'slug'=>$request->slug
                ,'foto'=>$foto
            ]
        );
         return redirect('category');
    }

    public function deleteCategory($id)
    {
        DB::table('categories')->where('id',$id)->delete();
        return redirect()->back();
    }
}
